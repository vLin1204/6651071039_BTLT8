$(document).ready(function () {
    $('#togglePassword').click(function () {
        const passwordInput = $('#password');
        const type = passwordInput.attr('type') === 'password' ? 'text' : 'password';
        passwordInput.attr('type', type);
        
        // Đổi icon mắt (Mở/Đóng)
        $(this).text(type === 'password' ? '👁️' : '🙈');
    });
});