$(document).ready(function () {
    // Hàm kiểm tra định dạng email
    function validateEmail(email) {
        var regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return regex.test(email);
    }

    // 1. Thêm hàng
    $('#btnAdd').click(function () {
        var name = $('#txtName').val().trim();
        var email = $('#txtEmail').val().trim();
        var birthdate = $('#txtBirthdate').val();

        if (name === "" || email === "" || birthdate === "") {
            alert("Vui lòng nhập đầy đủ thông tin!");
            return;
        }

        if (!validateEmail(email)) {
            alert("Email không đúng định dạng!");
            return;
        }

        var newRow = `<tr>
            <td><input type="checkbox"></td>
            <td>${name}</td>
            <td>${email}</td>
            <td>${birthdate}</td>
        </tr>`;

        $('#dataTable tbody').append(newRow);

        // Reset input
        $('#txtName').val('');
        $('#txtEmail').val('');
        $('#txtBirthdate').val('');
    });

    // 2. Xóa các hàng đã tích checkbox
    $('#btnDelete').click(function () {
        $('#dataTable tbody input[type="checkbox"]:checked').each(function () {
            $(this).closest('tr').remove();
        });
    });
});