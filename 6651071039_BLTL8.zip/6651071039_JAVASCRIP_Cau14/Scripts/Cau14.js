$(document).ready(function () {
    $('#themeToggle').change(function () {
        if ($(this).is(':checked')) {
            $('body').removeClass('dark-theme').addClass('light-theme');
            $('#themeLabel').text('Chế độ: Light (On)');
        } else {
            $('body').removeClass('light-theme').addClass('dark-theme');
            $('#themeLabel').text('Chế độ: Dark (Off)');
        }
    });
});