/* 
==================================================================================
  CÂU 5: SHOP PHỤ KIỆN ĐIỆN THOẠI MINI VỚI VUE.JS 3 (CDN)
==================================================================================
  [GHI CHÚ SO SÁNH VỚI VANILLA JS CỦA MÔ HÌNH REACTIVITY]:
  - Nếu dùng Vanilla JS: Mỗi lần thêm/xóa giỏ hàng hoặc tìm kiếm sản phẩm, 
    ta bắt buộc phải gọi document.querySelector(), tạo chuỗi HTML bằng tay 
    và cập nhật lại DOM thủ công rất rườm rà, dễ phát sinh lỗi.
  - Khi dùng Vue.js 3: Vue tự động quản lý luồng dữ liệu thông qua cơ chế REACTIVITY.
    Ta chỉ cần cập nhật mảng cart hoặc biến tuKhoa, giao diện (UI) ở header, 
    aside giỏ hàng và danh sách sản phẩm sẽ TỰ ĐỘNG CẬP NHẬT TỨC THỜI mà không cần
    thao tác DOM thủ công nào!
==================================================================================
*/

const { createApp } = Vue;

createApp({
    data() {
        return {
            // Biến liên kết 2 chiều v-model tìm kiếm
            tuKhoa: '',

            // Mảng chứa danh sách giỏ hàng
            cart: [],

            // Mảng chứa 8 sản phẩm phụ kiện điện thoại (lấy hình trong thư mục Images)
            products: [
                { id: 1, name: 'ELECTRIC BLUE CASE', price: 250000, description: 'Ốp lưng Silicon chống sốc cao cấp', image: 'Images/item1.jpg' },
                { id: 2, name: 'ELECTRIC BLUE CASE', price: 250000, description: 'Ốp lưng viền nổi siêu bảo vệ', image: 'Images/item2.jpg' },
                { id: 3, name: 'WIRELESS CHARGER PAD', price: 250000, description: 'Đế sạc không dây nhanh 15W', image: 'Images/item3.jpg' },
                { id: 4, name: 'ACTIVE TWS EARBUDS', price: 350000, description: 'Tai nghe Bluetooth âm thanh vòm', image: 'Images/item4.jpg' },
                { id: 5, name: 'ELECTRIC BLUE CASE', price: 250000, description: 'Ốp lưng MagSafe trong suốt', image: 'Images/item5.jpg' },
                { id: 6, name: 'WIRELESS CHARGER PAD', price: 250000, description: 'Đế sạc không dây tản nhiệt nhôm', image: 'Images/item6.jpg' },
                { id: 7, name: 'ACTIVE TWS EARBUDS', price: 250000, description: 'Tai nghe chống ồn chủ động ANC', image: 'Images/item7.jpg' },
                { id: 8, name: 'ACTIVE TWS EARBUDS', price: 250000, description: 'Cáp sạc siêu nhanh Type-C 65W', image: 'Images/item8.jpg' }
            ]
        };
    },

    computed: {
        // Computed Property 1: Tự động đếm tổng số lượng sản phẩm trong giỏ hàng
        cartCount() {
            return this.cart.length;
        },

        // Computed Property 2: Tự động tính tổng tiền giỏ hàng mỗi khi mảng cart thay đổi
        tongTien() {
            return this.cart.reduce((total, item) => total + item.price, 0);
        },

        // Computed Property 3: Tự động lọc sản phẩm theo từ khóa tìm kiếm (khi dùng v-model tuKhoa)
        danhSachLoc() {
            if (!this.tuKhoa) return this.products;
            const key = this.tuKhoa.toLowerCase().trim();
            return this.products.filter(p => 
                p.name.toLowerCase().includes(key) || 
                p.description.toLowerCase().includes(key)
            );
        }
    },

    methods: {
        // Method 1: Thêm sản phẩm vào mảng giỏ hàng cart
        themVaoGio(sanPham) {
            this.cart.push({ ...sanPham });
        },

        // Method 2: Xóa sản phẩm khỏi mảng giỏ hàng theo vị trí index
        xoaKhoiGio(index) {
            this.cart.splice(index, 1);
        },

        // Method 3: Format hiển thị định dạng tiền tệ VNĐ
        formatTien(gia) {
            return gia.toLocaleString('vi-VN') + ' VNĐ';
        }
    }
}).mount('#app');