$(document).ready(function () {
    $('.accordion-header').click(function () {
        var $content = $(this).next('.accordion-content');

        // Đóng các content khác và toggle content được click
        $('.accordion-content').not($content).slideUp();
        $('.accordion-header').not($(this)).removeClass('active');

        $content.slideToggle();
        $(this).toggleClass('active');
    });
});