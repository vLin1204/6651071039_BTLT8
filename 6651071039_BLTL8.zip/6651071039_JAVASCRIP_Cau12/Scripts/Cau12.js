$(document).ready(function () {
    // 1. Xử lý khi chọn/thay đổi ở phần Passport
    $('input[name="passport"]').change(function () {
        if ($(this).val() === 'yes') {
            $('#passportInputGroup').slideDown(300); // Hiện textbox Passport
        } else {
            $('#passportInputGroup').slideUp(300);   // Ẩn textbox Passport
            $('#passportNumber').val('');             // Xóa dữ liệu đã nhập
        }
    });

    // 2. Xử lý khi chọn/thay đổi ở phần Credit Card
    $('input[name="creditCard"]').change(function () {
        if ($(this).val() === 'yes') {
            $('#creditCardInputGroup').slideDown(300); // Hiện textbox Credit Card
        } else {
            $('#creditCardInputGroup').slideUp(300);   // Ẩn textbox Credit Card
            $('#cardNumber').val('');                  // Xóa dữ liệu đã nhập
        }
    });
});