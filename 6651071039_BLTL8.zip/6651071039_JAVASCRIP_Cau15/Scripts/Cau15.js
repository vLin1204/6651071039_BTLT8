$(document).ready(function () {
    $('.tab-menu li').click(function () {
        var tabId = $(this).attr('data-tab');

        $('.tab-menu li').removeClass('active');
        $('.content-item').removeClass('active');

        $(this).addClass('active');
        $('#' + tabId).addClass('active');
    });
});